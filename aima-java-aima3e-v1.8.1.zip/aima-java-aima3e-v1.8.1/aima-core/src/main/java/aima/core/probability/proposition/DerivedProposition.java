package aima.core.probability.proposition;

public interface DerivedProposition extends SentenceProposition {
	String getDerivedName();
}
