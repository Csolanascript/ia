package aima.core.environment.canibales;

import java.util.LinkedHashSet;
import java.util.Set;

import aima.core.agent.Action;
import aima.core.search.framework.ActionsFunction;
import aima.core.search.framework.ResultFunction;

/**
 * @author Ravi Mohan
 * @author Ciaran O'Reilly
 */
public class EightPuzzleFunctionFactory {
	private static ActionsFunction _actionsFunction = null;
	private static ResultFunction _resultFunction = null;

	public static ActionsFunction getActionsFunction() {
		if (null == _actionsFunction) {
			_actionsFunction = new EPActionsFunction();
		}
		return _actionsFunction;
	}

	public static ResultFunction getResultFunction() {
		if (null == _resultFunction) {
			_resultFunction = new EPResultFunction();
		}
		return _resultFunction;
	}

	private static class EPActionsFunction implements ActionsFunction {
		public Set<Action> actions(Object state) {
			EightPuzzleBoard board = (EightPuzzleBoard) state;

			Set<Action> actions = new LinkedHashSet<Action>();

			if (board.canMoveGap(EightPuzzleBoard.MOVER1C)) {
				actions.add(EightPuzzleBoard.MOVER1C);
			}
			if (board.canMoveGap(EightPuzzleBoard.MOVER2C)) {
				actions.add(EightPuzzleBoard.MOVER2C);
			}
			if (board.canMoveGap(EightPuzzleBoard.MOVER1M)) {
				actions.add(EightPuzzleBoard.MOVER1M);
			}
			if (board.canMoveGap(EightPuzzleBoard.MOVER2M)) {
				actions.add(EightPuzzleBoard.MOVER2M);
			}
			if (board.canMoveGap(EightPuzzleBoard.MOVER1M1C)) {
				actions.add(EightPuzzleBoard.MOVER1M1C);
			}


			return actions;
		}
	}

	private static class EPResultFunction implements ResultFunction {
		public Object result(Object s, Action a) {
			EightPuzzleBoard board = (EightPuzzleBoard) s;

			if (EightPuzzleBoard.MOVER1C.equals(a)
					&& board.canMoveGap(EightPuzzleBoard.MOVER1C)) {
				EightPuzzleBoard newBoard = new EightPuzzleBoard(board);
				newBoard.moveMOVER1C();
				return newBoard;
			} else if (EightPuzzleBoard.MOVER2C.equals(a)
					&& board.canMoveGap(EightPuzzleBoard.MOVER2C)) {
				EightPuzzleBoard newBoard = new EightPuzzleBoard(board);
				newBoard.MOVER2C();
				return newBoard;
			} else if (EightPuzzleBoard.MOVER1M.equals(a)
					&& board.canMoveGap(EightPuzzleBoard.MOVER1M)) {
				EightPuzzleBoard newBoard = new EightPuzzleBoard(board);
				newBoard.MOVER1M();
				return newBoard;
			} else if (EightPuzzleBoard.MOVER2M.equals(a)
					&& board.canMoveGap(EightPuzzleBoard.MOVER2M)) {
				EightPuzzleBoard newBoard = new EightPuzzleBoard(board);
				newBoard.MOVER2M();
				return newBoard;
			}
			else if (EightPuzzleBoard.MOVER1M1C.equals(a)
					&& board.canMoveGap(EightPuzzleBoard.MOVER1M1C)) {
				EightPuzzleBoard newBoard = new EightPuzzleBoard(board);
				newBoard.MOVER1M1C();
				return newBoard;
			}

			// The Action is not understood or is a NoOp
			// the result will be the current state.
			return s;
		}
	}
}